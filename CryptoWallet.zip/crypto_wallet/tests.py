
from django.test import TestCase
from .models import Wallet

class WalletTestCase(TestCase):
    def setUp(self):
        Wallet.objects.create(name="Test Wallet", balance=100.00)

    def test_wallet_balance(self):
        wallet = Wallet.objects.get(name="Test Wallet")
        self.assertEqual(wallet.balance, 100.00)
