from django.urls import path
import views

urlpatterns = [
    path('', views.DashboardView.as_view(), name='dashboard'),
    path('wallets/', views.WalletListView.as_view(), name='wallet_list'),
    path('wallets/<int:pk>/', views.WalletDetailView.as_view(), name='wallet_detail'),
    path('wallets/create/', views.WalletCreateView.as_view(), name='wallet_create'),
    path('wallets/<int:pk>/update/', views.WalletUpdateView.as_view(), name='wallet_update'),
    path('wallets/<int:pk>/delete/', views.WalletDeleteView.as_view(), name='wallet_delete'),
    path('transactions/search/', views.TransactionSearchView.as_view(), name='transaction_search'),
    path('transactions/report/', views.transaction_pdf_report, name='transaction_pdf_report'),
    path('about/', views.about_view, name='about'),
    path('contact/', views.contact_view, name='contact'),
    path('register/', views.register, name='register'),
]
